3D models of the frame (STL files and source files) go here.
