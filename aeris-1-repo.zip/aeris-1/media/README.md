Photos and videos of the build go here.
